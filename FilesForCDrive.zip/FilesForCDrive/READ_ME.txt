In order to get my program to work you will need to add some files to visual studio itself


You need to copy the curl folder into:
C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\include


You need to copy the libcurld_imp.lib into:
C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\lib