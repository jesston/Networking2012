//#include <string>
//http://msdn.microsoft.com/en-us/library/ms235636%28v=vs.80%29.aspx

namespace ParseFuncs
{
	class Parsing
	{
	public:
		static _declspec(dllexport) char* parseString();
		static _declspec(dllexport) char* parseString(char* object, char* openTag, char* endTag);
	};
}