#include "MyParseDll.h"

#include <string>

#include <stdexcept>

#include <sstream>
#include <string>

using namespace std;

namespace ParseFuncs
{
	char* Parsing::parseString()
	{
		//return 1;
		return "hello";
	}


	char* Parsing::parseString(char* object, char* openTag, char* endTag)
	{
		stringstream ssin(object);
		stringstream ssout(stringstream::in | stringstream::out);
		string returnable;

		string openTagString = openTag;
		string endTagString = endTag;

		ssin << object;

		char c;
		char oaat;
		//string reading;
		char* reading = new char();

		bool parsing = false;

		while(!ssin.eof())
		{
			c = ssin.peek();
		
			if (c == '<')
			{

				if (!parsing)
				{
					//keep reading
					ssin.readsome(reading, openTagString.length());

					if (reading == openTag)
					{
						parsing = true;
						/*c = ssin.peek();
						while( c != 

						ssin >> oaat;*/

					}
				}

				else//if (parsing)
				{
					ssin.readsome(reading, endTagString.length());

					if (reading == endTag)
					{
						parsing = false;
					}
				}
			}


			ssin >> oaat;

			if (parsing)
			{	
				returnable += oaat;
				//cout << returnable << "\nherny\n";
			}
		}	
		//returnable = ss.str();

		const char* ret = returnable.c_str();
		char* q = const_cast<char*>(ret);
		return q;
	}

}