#include <stdio.h>

#include <Windows.h>
#include <iostream>

#include <string>
#include <cstring>

#include <curl/curl.h>

#include <sstream>

#include "MyParseDll.h"

//using namespace System;


/*
http://curl.haxx.se/libcurl/
libCurl is used to query and return data from a html location.

http://www.grinninglizard.com/tinyxml/
tinyXML is used to parse the xml.
*/

using namespace std;

static string thisthing;

void function_pt(char *ptr, size_t size, size_t nmemb, void *stream)
{
	thisthing = ptr;
	cout << "\nGathering Responce\n";
}

/*string parse(string object, string openTag, string endTag)
{

	stringstream ssin(object);
	stringstream ssout(stringstream::in | stringstream::out);
	string returnable;

	ssin << object;

	char c;
	char oaat;
	//string reading;
	char* reading = new char();

	bool parsing = false;

	while(!ssin.eof())
	{
		c = ssin.peek();
		
		if (c == '<')
		{

			if (!parsing)
			{
				//keep reading
				ssin.readsome(reading, openTag.length());

				if (reading == openTag)
				{
					parsing = true;
					/*c = ssin.peek();
					while( c != 

					ssin >> oaat;*/

				/*}
			}

			else//if (parsing)
			{
				ssin.readsome(reading, endTag.length());

				if (reading == endTag)
				{
					parsing = false;
				}
			}
		}


		ssin >> oaat;

		if (parsing)
		{	
			returnable += oaat;
			cout << returnable << "\nherny\n";
		}
	}	
	//returnable = ss.str();

	return returnable;
}*/

int main()
{
	//get xml String
	cout << "get xml string\n";
	string uri2 = "http://graphical.weather.gov/xml/sample_products/browser_interface/ndfdXMLclient.php?whichClient=NDFDgen&lat=38.99&lon=-77.01&listLatLon=&lat1=&lon1=&lat2=&lon2=&resolutionSub=&listLat1=&listLon1=&listLat2=&listLon2=&resolutionList=&endPoint1Lat=&endPoint1Lon=&endPoint2Lat=&endPoint2Lon=&listEndPoint1Lat=&listEndPoint1Lon=&listEndPoint2Lat=&listEndPoint2Lon=&zipCodeList=&listZipCodeList=&centerPointLat=&centerPointLon=&distanceLat=&distanceLon=&resolutionSquare=&listCenterPointLat=&listCenterPointLon=&listDistanceLat=&listDistanceLon=&listResolutionSquare=&citiesLevel=&listCitiesLevel=&sector=&gmlListLatLon=&featureType=&requestedTime=&startTime=&endTime=&compType=&propertyName=&product=time-series&begin=2004-01-01T00%3A00%3A00&end=2016-01-20T00%3A00%3A00&Unit=e&maxt=maxt&Submit=Submit";
	
	CURL *curl;
	CURLcode res;

	curl = curl_easy_init();
	
	if (curl)
	{

		//curl_easy_setopt(curl, CURLOPT_URL, "http://www.facebook.com/?ref=logo");
		curl_easy_setopt(curl, CURLOPT_URL, "http://www.amazon.com/");
		//curl_easy_setopt(curl, CURLOPT_URL, uri2);
		
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, function_pt);
		res = curl_easy_perform(curl);


		//reference for writefunction
		//http://stackoverflow.com/questions/2329571/c-libcurl-get-output-into-a-string
		//http://curl.haxx.se/libcurl/c/curl_easy_setopt.html

		//Always clean up
		curl_easy_cleanup(curl);

		cout << "\nfrank\n" << thisthing << "\nBoo I'm scaryy";
	}

	//how do deal with error
	/*http://curl.haxx.se/docs/faq.html#Link_errors_when_building_libcur*/

	//process xml String
	cout << "\nProcess String\n";

	//string bob = ParseFuncs::Parsing::parseString(thisthing, "<script>", "</script>");
	//cout << bob << '\n';

	string phil = ParseFuncs::Parsing::parseString();
	cout << phil;

	//pause program and end
	system("Pause");
	return 0;
}

